package q3;

import java.awt.Color;

public interface MarineAnimal {
	
	public void PaintFish(Color clr);
	
}
