package q3;

import java.awt.Graphics;

public interface SeaCreature {
	public void drawCreature(Graphics g);
}
