package q3;

public interface HungerState {
	public void doAction(Swimmable swim);
}
