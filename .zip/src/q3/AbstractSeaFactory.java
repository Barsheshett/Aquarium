package q3;

public interface AbstractSeaFactory {
	public SeaCreature produceSeaCreature(String type);
}
